import pandas as pd


file_path = 'c:/Mtest/TeamPJ/구단별상관관계/상관관계_2.csv'
# 3번째 행부터 데이터 읽기
df = pd.read_csv(file_path, encoding='cp949', skiprows=2)


행이름들 = df.iloc[:, 0].unique()  # 첫 번째 열에 있는 고유한 행 이름을 가져옵니다.

# 결과를 저장할 딕트
결과 = {}

# 각 행 이름에 대해 평균 계산
for 행이름 in 행이름들:
    values = []
    
    # 모든 행을 반복
    for i in range(len(df)):
        if 행이름 in df.iloc[i].values:  # 현재 행 이름이 존재하면
            for j in range(0, len(df.columns), 2):  # 짝수 열 인덱스
                if df.iloc[i, j] == 행이름:  # 해당 행 이름 확인
                    try:
                        # 짝수 열 다음 열의 값을 숫자로 변환 후 추가
                        value = float(df.iloc[i, j + 1])
                        values.append(value)
                    except ValueError:
                        print(f"'{df.iloc[i, j + 1]}'는 숫자로 변환할 수 없습니다.")

    # 값들의 평균 계산
    if values:  # values가 비어있지 않을 때만 평균 계산
        평균 = sum(values) / len(values)
        결과[행이름] = 평균

# NaN 값이 없는 결과만 정렬하여 출력 (내림차순)
결과 = {행이름: 평균 for 행이름, 평균 in 결과.items() if 평균 is not None}
결과 = dict(sorted(결과.items(), key=lambda item: item[1], reverse=True))

# 결과 출력
# for 행이름, 평균 in 결과.items():
#     print(f"{행이름} 상관관계  평균: {평균}")

결과_df = pd.DataFrame(list(결과.items()), columns=['행 이름', '상관관계 평균'])


결과_df.to_csv('상관관계평균.csv', index=False, encoding='utf-8-sig')

