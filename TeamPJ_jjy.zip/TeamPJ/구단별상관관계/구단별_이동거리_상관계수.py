import pandas as pd

# CSV 파일 읽기
file_path = 'c:/Mtest/TeamPJ/data/구단별누적거리연봉승률.csv'  # 파일 경로를 실제 파일 위치에 맞게 수정하세요.
df = pd.read_csv(file_path, encoding='cp949')


data = df[df['팀명'] == 'NC']

# 승률을 %로 변환
data['승률'] = data['승률'] * 100

# 누적 이동 거리와 승률 간의 상관 계수 계산
correlation = data['누적이동거리'].corr(data['승률'])

# 결과 출력
print(f"누적 이동 거리와 승률(%) 간의 상관 계수: {correlation}")

data = df[df['팀명'] == 'NC']

# 승률을 %로 변환

# 평균 연봉과 승률 간의 상관 계수 계산
correlation_avg_salary_win_rate = data['평균연봉'].corr(data['승률'])

# 결과 출력
print(f"평균 연봉과 승률(%) 간의 상관 계수: {correlation_avg_salary_win_rate}")