import pandas as pd
import matplotlib.pyplot as plt

# 한글 폰트 설정
import matplotlib.font_manager as fm
font_name = fm.FontProperties(fname='C:/Windows/Fonts/malgun.ttf').get_name()
plt.rc('font', family=font_name)

# 데이터 불러오기
file_paths = {
    'team_data': './구단별_10년_승률.csv',
    'defense_data': './팀별_수비_기록.csv',
    'hitter_data': './팀별_타자_기록.csv',
    'pitcher_data': './팀별_투수_기록.csv'
}

team_data = pd.read_csv(file_paths['team_data'], encoding='cp949')
defense_data = pd.read_csv(file_paths['defense_data'])
hitter_data = pd.read_csv(file_paths['hitter_data'])
pitcher_data = pd.read_csv(file_paths['pitcher_data'])

def convert_to_numeric(df):
    # '연도', '순위'를 제외한 나머지 열 선택 후 변환
    cols_to_convert = df.columns.difference(['연도', '순위', '팀명'])
    df[cols_to_convert] = df[cols_to_convert].apply(pd.to_numeric, errors='coerce')
    return df

# 각 데이터셋에 적용
defense_data = convert_to_numeric(defense_data)
hitter_data = convert_to_numeric(hitter_data)
pitcher_data = convert_to_numeric(pitcher_data)
cols_to_convert = team_data.columns.difference(['연도', '팀명'])
team_data[cols_to_convert] = team_data[cols_to_convert].apply(pd.to_numeric, errors='coerce')

def summarize_data(team_name):
    # 'SK'를 'SSG'로 변환
    if team_name == 'SK':
        team_name = 'SSG'

    # 팀 데이터 필터링
    team_data_grouped = team_data[team_data['팀명'].isin([team_name, 'SK'])].drop(columns=['팀명'])
    hitter_data_grouped = hitter_data[hitter_data['팀명'].isin([team_name, 'SK'])].drop(columns=['팀명'])
    pitcher_data_grouped = pitcher_data[pitcher_data['팀명'].isin([team_name, 'SK'])].drop(columns=['팀명'])
    defense_data_grouped = defense_data[defense_data['팀명'].isin([team_name, 'SK'])].drop(columns=['팀명'])

    # 필요한 열을 수치형으로 변환
    team_data_grouped['승률'] = pd.to_numeric(team_data_grouped['승률'], errors='coerce')

    # 데이터 병합
    merged = pd.merge(team_data_grouped, hitter_data_grouped, on='연도', suffixes=('_팀', '_타자'))
    merged = pd.merge(merged, pitcher_data_grouped, on='연도', suffixes=('', '_투수'))
    merged = pd.merge(merged, defense_data_grouped, on='연도', suffixes=('', '_수비'))
    
    # 결과 출력 및 저장
    print(merged)
    output_file = f"c:/Mtest/TeamPJ/구단별상관관계/{team_name}_결합_기록.csv"
    merged.to_csv(output_file, index=False, encoding='utf-8-sig')
    return merged

# 사용자 입력 받기
team_name_input = str(input("원하는 팀명을 입력하세요 (예: 삼성): "))
merged_data = summarize_data(team_name_input)