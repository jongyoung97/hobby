import pandas as pd

file_path = 'c:/Mtest/TeamPJ/구단별상관관계/구단별_10년_승률(관중수,누적거리).csv'
print('성공')
df = pd.read_csv(file_path,encoding='cp949')

data = df[df['팀명'] == '한화']

correlation = data['관중수'].corr(data['승률'])

print(f"관중수와 승률 간의 상관 계수: {correlation}")