import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select


url = "https://www.mlb.com/standings/regular-season/mlb/2021"
driver = webdriver.Chrome()
driver.get(url)

year_select = (driver.find_elements(By.CLASS_NAME,'S'))


team_names = []

for i in range(1,31):
    team_select = driver.find_element(By.XPATH,f'//*[@id="standings-app-root"]/section/div[5]/div/div/table/tbody/tr[{i}]/th/div/div/a[2]')
    team_names.append(team_select.text)

df = pd.DataFrame(team_names,columns=['순위'])
print(df)