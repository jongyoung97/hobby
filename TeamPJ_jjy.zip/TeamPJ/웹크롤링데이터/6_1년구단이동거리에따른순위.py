import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import time
import numpy as np
import matplotlib as mpl

font_name = matplotlib.font_manager.FontProperties(fname='C:/Windows/Fonts/malgun.ttf').get_name()
matplotlib.rc('font', family=font_name)

import matplotlib as mpl 
mpl.rc('axes', unicode_minus=False)
mpl.rcParams['axes.unicode_minus'] = False

file_path = './data/이동거리_순위.csv'
df = pd.read_csv(file_path,encoding='cp949')
data = df[df['연도']==2019]
print(data)
x = np.array(data['누적이동거리'])
y = np.array(data['순위'])
team_names = np.array(data['팀명'])

su = np.polyfit(x,y,1)
print(su)      
m,b=su
fx = m*x+b
plt.scatter(x,y,color='None',edgecolors='blue',label='구단 순위')
plt.plot(x,fx,color='red')
plt.title('2019년 누적이동거리에 따른 순위')
plt.xlabel('이동거리(km)')
plt.ylabel('순위')
plt.ylim(0,11)
plt.gca().invert_yaxis()
plt.yticks(np.arange(1, 11, 1))
for i in range(len(x)):
    plt.text(x[i], y[i] + 0.1, team_names[i], ha='left', fontsize=9)

plt.legend()
plt.grid()
plt.show()