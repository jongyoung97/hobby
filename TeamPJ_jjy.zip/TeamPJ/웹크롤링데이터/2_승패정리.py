import pandas as pd

file_path = 'C:\\Mtest\\TeamPJ\\한화_데이터.csv'  # 경로에서 \\ 사용

lotte_data = pd.read_csv(file_path)

def team_result(row):
    if row['홈팀'] == '한화':
        return '승' if row['홈팀점수'] > row['원정팀점수'] else '패'
    else:  # 원정팀이 롯데
        return '승' if row['원정팀점수'] > row['홈팀점수'] else '패'

# Apply this function to add results column
lotte_data['한화결과'] = lotte_data.apply(team_result, axis=1)

# Wins와 Losses 초기화
lotte_data['Wins'] = 0
lotte_data['Losses'] = 0

# 연도별로 Wins와 Losses 계산
for year in lotte_data['연도'].unique():
    year_data = lotte_data[lotte_data['연도'] == year]
    
    # 누적 승리와 패배 계산
    wins_count = 0
    losses_count = 0
    for index, row in year_data.iterrows():
        if row['한화결과'] == '승':
            wins_count += 1
        else:
            losses_count += 1
            
        lotte_data.at[index, 'Wins'] = wins_count
        lotte_data.at[index, 'Losses'] = losses_count

# 결과를 CSV 파일로 저장
lotte_data.to_csv(file_path, index=False, encoding='utf-8-sig')

# 결과 출력 (선택 사항)
# print(lotte_data[['Date', '구장', '원정팀', '원정팀점수', '홈팀점수', '홈팀', '연도', '롯데결과', 'Wins', 'Losses']])