import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import time
import numpy as np
import matplotlib as mpl

font_name = matplotlib.font_manager.FontProperties(fname='C:/Windows/Fonts/malgun.ttf').get_name()
matplotlib.rc('font', family=font_name)

import matplotlib as mpl 
mpl.rc('axes', unicode_minus=False)
mpl.rcParams['axes.unicode_minus'] = False

years = range(2015,2025)
colors = plt.cm.viridis(np.linspace(0, 1, len(years)))

file_path = './data/연도별구단평균연봉.xlsx'
df = pd.read_excel(file_path)

fig, axs = plt.subplots(2, 5, figsize=(20, 10))  # 2행 5열의 서브플롯
axs = axs.flatten()  # 1차원 배열로 변환


for i,year in enumerate(years):
    data = df[df['연도']==year] 
    x = np.array(data['평균연봉'])
    y = np.array(data['리그순위'])
    team_names = np.array(data['팀명'])

    su = np.polyfit(x,y,1)     
    m,b=su
    fx = m*x+b
    axs[i].scatter(x,y,color='None',edgecolors='blue',label='구단 순위')
    axs[i].plot(x,fx,color='red',linestyle=':')

    for j in range(len(x)):
        axs[i].text(x[j],y[j]+0.1,team_names[j],ha='left',fontsize=9)


    axs[i].set_title(f'평균연봉에 따른 순위 ({year})')
    axs[i].set_xlabel('평균연봉(만원)')
    axs[i].set_ylabel('순위')
    axs[i].set_ylim(0, 11)
    axs[i].invert_yaxis()
    axs[i].set_yticks(np.arange(1, 11, 1))
    axs[i].grid()


plt.tight_layout()
plt.show()