import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import time
import numpy as np
import matplotlib as mpl

font_name = matplotlib.font_manager.FontProperties(fname='C:/Windows/Fonts/malgun.ttf').get_name()
matplotlib.rc('font', family=font_name)

import matplotlib as mpl 
mpl.rc('axes', unicode_minus=False)
mpl.rcParams['axes.unicode_minus'] = False

years = range(2015,2025)
colors = plt.cm.viridis(np.linspace(0, 1, len(years)))

file_path = './data/이동거리_순위.csv'
df = pd.read_csv(file_path,encoding='cp949')

fig, axs = plt.subplots(2, 5, figsize=(20, 10))  # 2행 5열의 서브플롯
axs = axs.flatten()  # 1차원 배열로 변환


for i,year in enumerate(years):
    data = df[df['연도']==year] 
    x = np.array(data['누적이동거리'])
    y = np.array(data['순위'])
    team_names = np.array(data['팀명'])

    su = np.polyfit(x,y,1)     
    m,b=su
    fx = m*x+b
    axs[i].scatter(x,y,color='None',edgecolors='blue',label='구단 순위')
    axs[i].plot(x,fx,color='red',linestyle=':')

    for j in range(len(x)):
        axs[i].text(x[j],y[j]+0.1,team_names[j],ha='left',fontsize=9)


    axs[i].set_title(f'누적이동거리에 따른 순위 ({year})')
    axs[i].set_xlabel('이동거리 (km)')
    axs[i].set_ylabel('순위')
    axs[i].set_ylim(0, 11)
    axs[i].invert_yaxis()
    axs[i].set_yticks(np.arange(1, 11, 1))
    axs[i].grid()


plt.tight_layout()
plt.show()