import pandas as pd

# CSV 파일 불러오기
file_path = 'c:/Mtest/TeamPJ/한화_데이터.csv'
df = pd.read_csv(file_path)

# 연도별로 그룹화하여 마지막 연도 포함
result = df.groupby('연도').last().reset_index()  # 각 연도의 마지막 행을 선택

# 승률 계산
result['승률'] = (result['Wins'] / (result['Wins'] + result['Losses'])) * 100
result['승률'] = result['승률'].round(1).astype(str) + '%'  # 소수 첫째자리 반올림 후 % 추가

# 최종 결과 선택
final_result = result[['연도', 'Wins', 'Losses', '승률']]

# 인덱스 제거 및 '팀명' 추가
final_result.reset_index(drop=True, inplace=True)  # 인덱스 제거
final_result.insert(0, '팀명', '한화')  # 첫 번째 열에 '팀명' 추가

# 결과 출력
print(final_result)

output_file_path = 'c:/Mtest/TeamPJ/한화_승률_결과.csv'
final_result.to_csv(output_file_path, index=False, encoding='utf-8-sig')




