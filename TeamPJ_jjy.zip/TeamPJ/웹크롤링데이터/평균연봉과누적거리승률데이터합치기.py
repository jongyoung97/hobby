import pandas as pd

# 두 CSV 파일 읽기
df_salary = pd.read_excel('./data/연도별구단평균연봉.xlsx')  # 평균연봉 데이터
df_distance = pd.read_csv('./data/이동거리_승률.csv', encoding='cp949')  # 이동거리 및 승률 데이터

# '팀명'과 '연도'를 기준으로 병합하여 '평균연봉' 추가
df_merged = df_distance.merge(df_salary[['팀명', '연도', '평균연봉']], on=['팀명', '연도'], how='left')

# 결과를 새로운 CSV 파일로 저장
df_merged.to_csv('./data/결과_이동거리_승률_평균연봉.csv', index=False, encoding='cp949')